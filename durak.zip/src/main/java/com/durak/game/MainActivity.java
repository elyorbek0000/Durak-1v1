package com.durak.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private WebView wv;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        wv = new WebView(this);
        setContentView(wv);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        wv.setBackgroundColor(0xFF0B1A10);
        wv.addJavascriptInterface(new Net(this, wv), "Net");
        wv.loadUrl("file:///android_asset/index.html");
        hideBars();
    }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @Override
    public void onBackPressed() {
        wv.evaluateJavascript("(window.onBack?window.onBack():false)", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String v) {
                if (!"true".equals(v)) finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        wv.removeJavascriptInterface("Net");
    }

    /** Simple TCP bridge: one host, one client, JSON lines. */
    static class Net {
        private final Activity act;
        private final WebView web;
        private final ExecutorService sender = Executors.newSingleThreadExecutor();
        private ServerSocket server;
        private Socket sock;
        private PrintWriter out;
        private int gen = 0;

        Net(Activity a, WebView w) {
            act = a;
            web = w;
        }

        private void js(final int g, final String type, final String data) {
            if (g != gen) return;
            act.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    web.evaluateJavascript("window.onNet&&window.onNet("
                            + JSONObject.quote(type) + "," + JSONObject.quote(data) + ")", null);
                }
            });
        }

        private synchronized int reset() {
            gen++;
            try { if (server != null) server.close(); } catch (Exception e) { }
            try { if (sock != null) sock.close(); } catch (Exception e) { }
            server = null;
            sock = null;
            out = null;
            return gen;
        }

        private synchronized void attach(Socket s) throws Exception {
            sock = s;
            s.setTcpNoDelay(true);
            out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), "UTF-8")), false);
        }

        private void readLoop(int g, Socket s) {
            try {
                BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
                String line;
                while ((line = r.readLine()) != null) js(g, "msg", line);
            } catch (Exception e) { }
            js(g, "closed", "");
        }

        @JavascriptInterface
        public String ip() {
            StringBuilder sb = new StringBuilder();
            try {
                for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                    if (!ni.isUp() || ni.isLoopback()) continue;
                    String n = ni.getName().toLowerCase();
                    if (n.startsWith("rmnet") || n.startsWith("ccmni") || n.startsWith("tun")
                            || n.startsWith("dummy") || n.startsWith("v4-")) continue;
                    for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                        if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                            if (sb.length() > 0) sb.append("  ");
                            sb.append(a.getHostAddress());
                        }
                    }
                }
            } catch (Exception e) { }
            return sb.toString();
        }

        @JavascriptInterface
        public void host(final int port) {
            final int g = reset();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        ServerSocket ss = new ServerSocket();
                        ss.setReuseAddress(true);
                        ss.bind(new InetSocketAddress(port));
                        synchronized (Net.this) { server = ss; }
                        js(g, "waiting", "");
                        Socket s = ss.accept();
                        attach(s);
                        js(g, "client", "");
                        readLoop(g, s);
                    } catch (Exception e) {
                        js(g, "error", String.valueOf(e.getMessage()));
                    }
                }
            }).start();
        }

        @JavascriptInterface
        public void connect(final String ip, final int port) {
            final int g = reset();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Socket s = new Socket();
                        s.connect(new InetSocketAddress(ip.trim(), port), 8000);
                        attach(s);
                        js(g, "connected", "");
                        readLoop(g, s);
                    } catch (Exception e) {
                        js(g, "error", String.valueOf(e.getMessage()));
                    }
                }
            }).start();
        }

        @JavascriptInterface
        public void send(final String m) {
            sender.execute(new Runnable() {
                @Override
                public void run() {
                    synchronized (Net.this) {
                        if (out != null) {
                            out.println(m);
                            out.flush();
                        }
                    }
                }
            });
        }

        @JavascriptInterface
        public void close() {
            reset();
        }
    }
}
